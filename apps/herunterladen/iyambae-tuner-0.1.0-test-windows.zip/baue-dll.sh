#!/bin/bash
#
# Baut den DSP-Kern als Windows-DLL — im Linux-Container, per Kreuzübersetzung.
#
# Warum so: Auf dem Entwicklungsrechner ist weder Visual Studio noch ein
# Windows SDK nötig. `mingw-w64` im Container genügt, und das Ergebnis läuft
# auf Windows nachweislich (siehe PORTING.md, Abschnitt 4).
#
# Aufruf vom Repo-Wurzelverzeichnis aus:
#
#   docker run --rm \
#       -v "$PWD:/src:ro" -v "$PWD/Prototyp/windows/lib:/out" \
#       debian:trixie-slim bash -lc "bash /src/Prototyp/windows/baue-dll.sh"
#
set -euo pipefail

QUELLE=${QUELLE:-/src}
ZIEL=${ZIEL:-/out}
export DEBIAN_FRONTEND=noninteractive

if ! command -v x86_64-w64-mingw32-gcc >/dev/null 2>&1; then
    echo "=== mingw-w64 nachinstallieren ==="
    apt-get update -qq >/dev/null 2>&1
    apt-get install -y -qq mingw-w64 >/dev/null 2>&1
fi
echo "  $(x86_64-w64-mingw32-gcc --version | head -1)"

mkdir -p "$ZIEL"

echo
echo "=== Übersetzen ==="
#
# Streng nach C11 und mit -pedantic: Die Zusage aus PORTING.md soll bei jedem
# Bau nachgewiesen werden, nicht behauptet. `M_PI` steht als eigene Konstante
# in der Datei, ein -D_USE_MATH_DEFINES ist deshalb nicht nötig — wäre es
# nötig, würde dieser Aufruf scheitern und den Rückfall sichtbar machen.
x86_64-w64-mingw32-gcc \
    -O2 -std=c11 -pedantic -Wall -Wextra \
    -shared \
    -o "$ZIEL/retuner_dsp.dll" \
    "$QUELLE/Sources/RetunerDSP/RetunerDSP.c" \
    -I"$QUELLE/Sources/RetunerDSP/include" \
    -Wl,--out-implib,"$ZIEL/retuner_dsp.lib"

echo "  $ZIEL/retuner_dsp.dll  ($(stat -c%s "$ZIEL/retuner_dsp.dll") Bytes)"

echo
echo "=== Exportierte Funktionen ==="
x86_64-w64-mingw32-nm -g --defined-only "$ZIEL/retuner_dsp.dll" \
    | grep -oE 'rt_(engine|switch|fifo)_[a-z_]+' | sort -u | sed 's/^/  /'
