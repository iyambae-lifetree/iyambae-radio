# IYAMBAE Tuner — Linux

Stimmt den Systemton unter PipeWire um. Derselbe Signalpfad wie die
macOS-Fassung von MyRetuner; neu geschrieben ist nur die Klammer darum — und
die ist kleiner ausgefallen als geplant.

## Wie es funktioniert

Das Umstimmen steckt in einem **LADSPA-Plugin**. Das Einhängen in den
Audiograph übernimmt **PipeWire selbst**:

```
  Anwendungen  →  IYAMBAE Tuner   (Wiedergabegerät, Audio/Sink)
                        │
                  module-filter-chain
                    └─ iyambae_tuner.so   ← RetunerDSP bzw. RetunerStretch
                        │
                  echtes Ausgabegerät
```

Kein eigener Dienst, der Knoten anlegt, verkabelt und Gerätewechsel
nachführt. PipeWire kann das, und es kann es besser — das ist keine
Bequemlichkeit, sondern eine Messung, siehe unten.

## Installieren

```bash
sudo apt install ./iyambae-tuner_0.1.0-1_amd64.deb
```

`apt` statt `dpkg -i`, damit fehlende Abhängigkeiten gleich mitkommen.

## Benutzen

```bash
iyambae-tuner start        # Dienst starten, ab jetzt auch beim Anmelden
iyambae-tuner standard     # zur Standardsenke machen
```

Ab hier läuft alles umgestimmt, was abgespielt wird. Im laufenden Betrieb,
ohne dass der Ton abreißt:

```bash
iyambae-tuner stimmung 528
iyambae-tuner stimmung 440     # wieder Kammerton
iyambae-tuner bypass an
iyambae-tuner status
```

Signalsmith statt Delay-Line:

```bash
iyambae-tuner stop
iyambae-tuner start hq
```

Vollständig: `man iyambae-tuner`.

## Welche Engine

| | Latenz | 432 Hz | 528 Hz | wofür |
|---|---|---|---|---|
| `start` (Delay-Line) | ~21 ms | +1,33 ct | −11,94 ct | Video, Spiele, Gespräche |
| `start hq` (Signalsmith) | ~240 ms | +0,35 ct | +0,85 ct | Musik |

Die Zahlen sind im Container gemessen (siehe „Prüfen"). Bei kleinen
Umstimmungen nehmen sich beide wenig; bei großen Sprüngen wird die
Delay-Line hörbar ungenau. Dieselbe Abweichung zeigt sie auch ohne PipeWire,
also allein gemessen — das ist die Engine, nicht die Anbindung.

Die Wahl fällt beim Start. Im Betrieb umzuschalten wäre nicht echtzeitsicher:
`rt_stretch_reset` ist es ausdrücklich nicht, und diese Grenze wird hier
nicht überschritten.

## Warum LADSPA und nicht ein eigener Dienst

`iyambae-tuner.c` im selben Verzeichnis baut das PipeWire-Knotenpaar von
Hand: zwei `pw_stream`, gemeinsame `node.link-group`, eigenes Anmelden als
Standardsenke samt Rückstellung beim Beenden. Der Signalweg stand damit. Die
Planung im Graphen nicht:

| Bauform | Ergebnis |
|---|---|
| ohne `PW_STREAM_FLAG_TRIGGER` | 141 Blöcke, 142 Zyklen ohne freien Ausgangspuffer — jeder zweite fällt aus |
| mit `TRIGGER` | Puffer immer da, aber 58 % Löcher im Mitschnitt |
| `node.always-process`, ohne `TRIGGER` | lückenlos, aber der Ausgang schickt in Zyklen ohne Eingang alte Puffer weiter: bei Faktor 1,0 kamen **428,3 statt 440,0 Hz** heraus |

Entschieden hat es der Kontrollversuch: PipeWires eigenes `module-loopback`
lief im selben Container lückenlos durch — 5,97 s am Stück, 440,000 Hz. Es
lag also nicht an der Umgebung, sondern daran, dass hier von Hand nachgebaut
wurde, was PipeWire fertig mitbringt.

Das ist zugleich der Weg, den `PORTING.md` unter „Linux" ohnehin vorschlägt.

`iyambae-tuner.c` bleibt im Repository liegen, weil es zwei Dinge zeigt, die
sonst nirgends stehen: wie man die Standardsenke über die PipeWire-Metadaten
setzt und beim Beenden zurücknimmt, und woran ein selbstgebautes Knotenpaar
scheitert. Ausgeliefert wird es nicht.

## Das Plugin allein

`iyambae_tuner.so` ist ein gewöhnliches LADSPA-Plugin und läuft in jedem
LADSPA-Wirt — Ardour, Audacity, `applyplugin` aus dem `ladspa-sdk`:

```
iyambae_tuner      Delay-Line, Ports: Factor, Bypass, In/Out L/R
iyambae_tuner_hq   Signalsmith, dieselben Ports
```

`Factor` ist das Frequenzverhältnis, nicht Hertz: 432 Hz entsprechen
432/440 = 0,981818.

## Was noch fehlt

Ehrlich, nicht beschönigt:

- **Keine grafische Oberfläche.** Kommandozeile und systemd, sonst nichts.
- **Keine Stimmungserkennung, keine Presets.** Beides liegt in den
  Swift-Teilen (`RetunerCore`) und ist hier nicht angebunden. Auf dem Mac
  erkennt die App die Stimmung des laufenden Stücks selbst; hier muss man
  sie sagen.
- **Fester Stereobetrieb.** Mehrkanalton wird von PipeWire auf Stereo
  heruntergemischt, bevor er den Tuner erreicht.
- **Kein Umschalten der Engine im Betrieb** (Begründung oben).
- **Keine Echtzeit-Priorität von selbst.** Ohne `rtkit` beziehungsweise
  passende Grenzen in `/etc/security/limits.d/` gibt es unter Last Aussetzer.
- **Nicht auf echter Hardware geprüft.** Alle Messungen liefen headless im
  Container gegen eine Null-Senke. Der Signalweg ist damit belegt, das
  Zusammenspiel mit echten Geräten, Gerätewechseln und Bluetooth nicht.
- **Nur auf Debian trixie gemessen** (PipeWire 1.4, WirePlumber 0.5). Für
  Zorin 18 / Ubuntu 24.04 (PipeWire 1.0, WirePlumber 0.4) muss neu gebaut
  und gemessen werden; `module-filter-chain` gibt es dort, geprüft ist es
  nicht.

## Bauen

Der Bau läuft im Container, damit das Paket gegen die Bibliotheken der
Zieldistribution gebunden ist und nicht gegen die des Entwicklungsrechners.

```bash
docker build -f Prototyp/linux/Dockerfile.bau -t iyambae-bau .
mkdir -p Prototyp/linux/bau
docker run --rm -v "$PWD:/src:ro" -v "$PWD/Prototyp/linux/bau:/out" \
    iyambae-bau bash /src/Prototyp/linux/baue-deb.sh
```

## Prüfen

Alle Prüfstände laufen ohne Soundkarte — PipeWire bekommt eine Null-Senke.

```bash
# Der wichtigste: installiert das .deb in einem Container OHNE Uebersetzer
# und misst den Signalweg von aussen.
docker run --rm -v "$PWD/Prototyp/linux/bau:/pakete:ro" \
    -v "$PWD/Prototyp/linux:/skripte:ro" debian:trixie-slim \
    bash /skripte/pruefe-paket.sh

# Punkt 5 aus PORTING.md: haelt die NaN-/Inf-Abfrage unter -ffast-math?
docker run --rm -v "$PWD:/src:ro" iyambae-bau \
    bash /src/Prototyp/linux/pruefe-fastmath.sh
```

| Skript | Frage |
|---|---|
| `pruefe-paket.sh` | Tut das **installierte Paket**, was es verspricht? |
| `pruefe-fastmath.sh` | Überlebt die NaN-/Inf-Abfrage `-ffast-math`? |
| `pruefe.sh` | Nachweis: läuft `RetunerDSP` im PipeWire-Rückruf? (Filterknoten, von Hand verkabelt) |
| `pruefe-senke.sh` | Nachweis: stimmt die virtuelle Senke um, ohne Verkabelung? |
| `pruefe-schlau.sh` | Hängt WirePlumber ≥ 0.5 einen Filter von selbst ein? |

Die letzten drei gehören zu den Vorstufen und sind aufgehoben, weil sie den
Weg dorthin belegen. Für das Paket zählt `pruefe-paket.sh`.

## Dateien

| Datei | Was |
|---|---|
| `ladspa-iyambae.c` | Das Plugin. Der ausgelieferte Signalpfad. |
| `iyambae-tuner.conf` | PipeWire-Filterkette; die HQ-Fassung entsteht daraus beim Bau |
| `iyambae-tuner.sh` | Steuerung: starten, Standardsenke, Stimmung im Betrieb |
| `baue-deb.sh` | Bau und Paketierung |
| `pruefe-paket.sh` | Prüfstand für das fertige Paket |
| `pruefe-fastmath.cpp/.sh` | Punkt 5 aus PORTING.md |
| `iyambae-tuner.c` | Verworfener eigener Dienst, mit Messwerten dokumentiert |
| `pw-retuner.c`, `pw-senke.c` | Frühere Machbarkeitsnachweise |
