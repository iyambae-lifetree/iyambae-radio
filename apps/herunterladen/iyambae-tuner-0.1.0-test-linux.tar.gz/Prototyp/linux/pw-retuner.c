/*
 MyRetuner als PipeWire-Filterknoten — Machbarkeitsnachweis.

 Zweck: zeigen, dass `RetunerDSP` unverändert im Echtzeit-Rückruf von
 PipeWire läuft und ein 440-Hz-Signal wirklich bei 432 Hz herauskommt.
 Das ist dasselbe Ergebnis, das auf Windows über die kreuzübersetzte DLL
 bereits belegt ist — hier im echten Audiograph statt im Testprogramm.

 Bauform: ein Knoten**paar** mit gemeinsamer `node.link-group`. WirePlumber
 erkennt nur Paare als Filter, nicht einzelne Knoten. `pw_filter` legt beide
 an, sobald Ein- und Ausgangsport vorhanden sind.

 Echtzeit-Disziplin wie auf dem Mac: Im Rückruf wird nicht alloziert, kein
 Lock genommen, nichts ausgegeben. Die Engine entsteht vorher, die Zähler
 sind atomar.

 Das hier ist ein Prototyp, keine Anwendung: kein Automatikmodus, keine
 Presets, keine Oberfläche, kein sauberer Abbau bei Gerätewechsel. Es soll
 genau eine Frage beantworten.
*/
#include <pipewire/pipewire.h>
#include <pipewire/filter.h>

#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

#include "RetunerDSP.h"

/*
 Stereo, nicht mono — und das ist keine Bequemlichkeit.

 WirePlumber hängt einen Filter nur dort ein, wo er passt. Ein Mono-Filter
 zwischen einem Stereo-Abspieler und einer Stereo-Senke passt nicht, also
 wird er stillschweigend übergangen: Der Ton läuft daran vorbei, der Filter
 verarbeitet null Blöcke, und nichts weist auf den Grund hin. Genau das ist
 hier beim ersten Versuch passiert.
*/
#define KANAELE 2

struct zustand {
    struct pw_main_loop *loop;
    struct pw_filter    *filter;
    float               *ein[KANAELE];
    float               *aus[KANAELE];

    RTEngine *engine;

    atomic_ullong bloecke;
    atomic_ullong rahmen;
    atomic_uint   spitze_promille;   /* atomic_float gibt es nicht ueberall */
};

/*
 Laeuft im Datenthread von PipeWire. Die Doku ist eindeutig: nur
 RT-sichere Aufrufe. Genau die Grenze, die `RetunerDSP.h` im Kopfkommentar
 ohnehin zieht — hier ist also nichts neu zu denken, nur einzuhalten.
*/
static void verarbeite(void *nutzdaten, struct spa_io_position *position)
{
    struct zustand *z = nutzdaten;
    uint32_t n = position->clock.duration;
    float spitze = 0.0f;

    for (uint32_t k = 0; k < KANAELE; k++) {
        float *ein = pw_filter_get_dsp_buffer(z->ein[k], n);
        float *aus = pw_filter_get_dsp_buffer(z->aus[k], n);
        if (!aus) continue;

        if (!ein) {
            /* Kein Eingang verbunden: Stille ausgeben statt alten Puffer. */
            memset(aus, 0, n * sizeof(float));
            continue;
        }

        /*
         Stride 1: PipeWire-DSP-Ports sind planar, ein Kanal je Port. Die
         Engine führt je Kanal einen eigenen Zustand — deshalb der Index.
        */
        rt_engine_process_channel(z->engine, k, ein, 1, aus, 1, n);

        for (uint32_t i = 0; i < n; i++) {
            float a = aus[i] < 0 ? -aus[i] : aus[i];
            if (a > spitze) spitze = a;
        }
    }

    atomic_fetch_add_explicit(&z->bloecke, 1, memory_order_relaxed);
    atomic_fetch_add_explicit(&z->rahmen, n, memory_order_relaxed);
    unsigned p = (unsigned)(spitze * 1000.0f);
    if (p > atomic_load_explicit(&z->spitze_promille, memory_order_relaxed))
        atomic_store_explicit(&z->spitze_promille, p, memory_order_relaxed);
}

static const struct pw_filter_events ereignisse = {
    PW_VERSION_FILTER_EVENTS,
    .process = verarbeite,
};

static struct pw_main_loop *g_loop;
static void bei_signal(void *d, int s) { (void)d; (void)s; pw_main_loop_quit(g_loop); }

int main(int argc, char **argv)
{
    double abtastrate = 48000.0;
    uint32_t verzoegerung = 2048;
    double faktor = 432.0 / 440.0;
    int schlau = 0;               /* --schlau: von WirePlumber einhängen lassen */
    const char *ziel = NULL;      /* --ziel <senke>: an welche Senke */

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--faktor") && i + 1 < argc)      faktor = atof(argv[++i]);
        else if (!strcmp(argv[i], "--rate") && i + 1 < argc)   abtastrate = atof(argv[++i]);
        else if (!strcmp(argv[i], "--frames") && i + 1 < argc) verzoegerung = (uint32_t)atoi(argv[++i]);
        else if (!strcmp(argv[i], "--schlau"))                 schlau = 1;
        else if (!strcmp(argv[i], "--ziel") && i + 1 < argc)   ziel = argv[++i];
    }

    struct zustand z = { 0 };

    /* Vor dem Graphen anlegen — im Rückruf darf nicht alloziert werden. */
    z.engine = rt_engine_create(abtastrate, verzoegerung);
    if (!z.engine) { fprintf(stderr, "Engine konnte nicht angelegt werden\n"); return 1; }
    rt_engine_set_factor(z.engine, faktor);

    printf("  Engine: %.0f Hz, %u Frames Verzoegerung, Faktor %.9f\n",
           abtastrate, verzoegerung, rt_engine_get_factor(z.engine));
    printf("  Latenz: %.2f ms\n", rt_engine_latency_seconds(z.engine) * 1000.0);

    pw_init(&argc, &argv);
    z.loop = pw_main_loop_new(NULL);
    g_loop = z.loop;
    pw_loop_add_signal(pw_main_loop_get_loop(z.loop), SIGINT,  bei_signal, NULL);
    pw_loop_add_signal(pw_main_loop_get_loop(z.loop), SIGTERM, bei_signal, NULL);

    struct pw_properties *eigenschaften = pw_properties_new(
        PW_KEY_MEDIA_TYPE,       "Audio",
        PW_KEY_MEDIA_CATEGORY,   "Filter",
        PW_KEY_MEDIA_ROLE,       "DSP",
        PW_KEY_NODE_NAME,        "myretuner",
        PW_KEY_NODE_DESCRIPTION, "MyRetuner",
        "node.link-group",       "myretuner",
        NULL);

    /*
     Ohne `--schlau` muss der Nutzer selbst verkabeln (`pw-link`) — brauchbar
     zum Prüfen, unzumutbar als Produkt.

     Mit `--schlau` hängt WirePlumber den Filter selbsttätig zwischen die
     Anwendungen und die Zielsenke, auch bei Gerätewechsel. Das gibt es erst
     ab WirePlumber 0.5.

     Zorin 18 baut auf Ubuntu 24.04 und liefert 0.4.17 — dort greift das
     **nicht**. Die Auslieferung braucht also beide Wege, mit Erkennung zur
     Laufzeit: schlau, wo es geht; sonst als virtuelle Senke anmelden und
     beim Start zur Standardsenke machen, beim Beenden zurückstellen.
    */
    if (schlau) {
        pw_properties_set(eigenschaften, "filter.smart", "true");
        pw_properties_set(eigenschaften, "filter.smart.name", "myretuner");
        if (ziel) pw_properties_set(eigenschaften, "filter.smart.target", ziel);
    }

    z.filter = pw_filter_new_simple(
        pw_main_loop_get_loop(z.loop), "myretuner", eigenschaften, &ereignisse, &z);
    if (!z.filter) { fprintf(stderr, "Filter konnte nicht angelegt werden\n"); return 1; }

    /*
     Portnamen `input_FL`/`output_FL` statt eigener Bezeichnungen: PipeWire
     und WirePlumber ordnen Kanäle über diese Namen zu. Mit Fantasienamen
     findet die selbsttätige Verkabelung keine Entsprechung.
    */
    static const char *lage[KANAELE] = { "FL", "FR" };
    for (uint32_t k = 0; k < KANAELE; k++) {
        char ein_name[32], aus_name[32];
        snprintf(ein_name, sizeof ein_name, "input_%s",  lage[k]);
        snprintf(aus_name, sizeof aus_name, "output_%s", lage[k]);

        z.ein[k] = pw_filter_add_port(z.filter, PW_DIRECTION_INPUT,
            PW_FILTER_PORT_FLAG_MAP_BUFFERS, sizeof(float),
            pw_properties_new(PW_KEY_FORMAT_DSP, "32 bit float mono audio",
                              PW_KEY_PORT_NAME, ein_name,
                              PW_KEY_AUDIO_CHANNEL, lage[k], NULL), NULL, 0);

        z.aus[k] = pw_filter_add_port(z.filter, PW_DIRECTION_OUTPUT,
            PW_FILTER_PORT_FLAG_MAP_BUFFERS, sizeof(float),
            pw_properties_new(PW_KEY_FORMAT_DSP, "32 bit float mono audio",
                              PW_KEY_PORT_NAME, aus_name,
                              PW_KEY_AUDIO_CHANNEL, lage[k], NULL), NULL, 0);
    }

    if (pw_filter_connect(z.filter, PW_FILTER_FLAG_RT_PROCESS, NULL, 0) < 0) {
        fprintf(stderr, "Verbindung zum Graphen fehlgeschlagen\n");
        return 1;
    }

    printf("  Filter haengt im Graphen.\n");
    fflush(stdout);

    pw_main_loop_run(z.loop);

    printf("  Bloecke %llu, Rahmen %llu, Spitze %.3f\n",
           (unsigned long long)atomic_load(&z.bloecke),
           (unsigned long long)atomic_load(&z.rahmen),
           atomic_load(&z.spitze_promille) / 1000.0);

    pw_filter_destroy(z.filter);
    pw_main_loop_destroy(z.loop);
    pw_deinit();
    rt_engine_destroy(z.engine);
    return 0;
}
