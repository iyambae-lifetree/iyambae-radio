#!/bin/bash
#
# Meldet sich MyRetuner als virtuelle Senke an — und stimmt um, ohne dass
# jemand von Hand verkabelt?
#
# Das ist die Frage, an der sich entscheidet, ob aus dem Nachweis ein Produkt
# werden kann. Geprüft wird: Anwendung spielt auf die Standardsenke, ohne
# etwas zu wissen. Kommt hinten 432 Hz heraus, trägt der Weg.
set -euo pipefail

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq >/dev/null 2>&1
apt-get install -y -qq pipewire pipewire-pulse wireplumber libpipewire-0.3-dev \
    pkg-config gcc pulseaudio-utils dbus-x11 python3 jq >/dev/null 2>&1

echo "=== Fassungen ==="
echo "  PipeWire    $(pkg-config --modversion libpipewire-0.3)"
echo "  WirePlumber $(dpkg-query -W -f='${Version}' wireplumber 2>/dev/null)"

echo
echo "=== Übersetzen ==="
gcc -O2 -std=c11 -pedantic -Wall -Wextra -c "$REPO/Sources/RetunerDSP/RetunerDSP.c" \
    -I"$REPO/Sources/RetunerDSP/include" -o /tmp/dsp.o
gcc -O2 -std=gnu11 -Wall -Wextra -c "$REPO/Prototyp/linux/pw-senke.c" \
    -I"$REPO/Sources/RetunerDSP/include" $(pkg-config --cflags libpipewire-0.3) \
    -o /tmp/senke.o
gcc /tmp/senke.o /tmp/dsp.o -o /tmp/pw-senke $(pkg-config --libs libpipewire-0.3) -lm
echo "  OK"

echo
echo "=== Graph starten ==="
export XDG_RUNTIME_DIR=/run/user/0
mkdir -p "$XDG_RUNTIME_DIR"; chmod 700 "$XDG_RUNTIME_DIR"
dbus-daemon --session --fork --print-address > /tmp/dbus.addr 2>/dev/null
export DBUS_SESSION_BUS_ADDRESS="$(cat /tmp/dbus.addr)"
pipewire       > /tmp/pw.log  2>&1 &
sleep 2
wireplumber    > /tmp/wp.log  2>&1 &
pipewire-pulse > /tmp/pwp.log 2>&1 &
sleep 3

# Das „echte Ausgabegerät" — im Container eine virtuelle Senke, deren Monitor
# wir mitschneiden können.
pactl load-module module-null-sink sink_name=lautsprecher >/dev/null
sleep 1

echo
echo "=== MyRetuner starten, Ziel: lautsprecher ==="
/tmp/pw-senke --ziel lautsprecher --faktor 0.98181818181818181818 > /tmp/s.log 2>&1 &
SPID=$!
sleep 4
sed 's/^/  /' /tmp/s.log

echo
echo "=== Taucht MyRetuner als Wiedergabegerät auf? ==="
pactl list short sinks 2>/dev/null | sed 's/^/  /'

echo
echo "=== Als Standardsenke setzen (der 0.4er Weg, ohne Smart Filter) ==="
pactl set-default-sink myretuner 2>/dev/null && echo "  gesetzt: $(pactl get-default-sink)" \
    || echo "  FEHLGESCHLAGEN — MyRetuner ist keine waehlbare Senke"
pactl set-default-source lautsprecher.monitor 2>/dev/null || true
echo "  Aufnahmequelle: $(pactl get-default-source 2>/dev/null)"

echo
echo "=== Verkabelung, wie sie sich von selbst ergeben hat ==="
pw-link -l 2>/dev/null | grep -A2 -i myretuner | head -16 | sed 's/^/  /'

echo
echo "=== Testton ohne jede Verkabelung durchschicken ==="
python3 - <<'ENDE'
import math, struct, wave
sr, hz, sek = 48000, 440.0, 5.0
with wave.open('/tmp/ton.wav','wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr)
    r = []
    for n in range(int(sr*sek)):
        v = int(0.6*32767*math.sin(2*math.pi*hz*n/sr))
        r.append(struct.pack('<hh', v, v))
    w.writeframes(b''.join(r))
ENDE

pw-record --channels 2 --rate 48000 /tmp/auf.wav 2>/dev/null &
RPID=$!
sleep 1
pw-play /tmp/ton.wav 2>/dev/null || true
sleep 1
kill -INT $RPID 2>/dev/null || true
wait $RPID 2>/dev/null || true

echo
echo "=== Messen ==="
python3 - <<'ENDE'
import wave, struct, math, sys
try: w = wave.open('/tmp/auf.wav','rb')
except Exception as e: print("  nicht lesbar:", e); sys.exit(0)
sr, n, br, kan = w.getframerate(), w.getnframes(), w.getsampwidth(), w.getnchannels()
if n == 0: print("  leer"); sys.exit(0)
fmt = {1:'b',2:'h',4:'i'}[br]; skala = float(1 << (br*8-1))
alle = struct.unpack(f'<{n*kan}{fmt}', w.readframes(n))
werte = [v/skala for v in alle[::kan]]
spitze = max(abs(v) for v in werte)
print(f"  {n} Rahmen, {kan} Kanaele, Spitze {spitze:.4f}")
if spitze < 0.001: print("  Stille — es floss nichts."); sys.exit(0)
a = werte[len(werte)//6 : 5*len(werte)//6]
# Median der Periodendauern statt Mittelwert ueber die ganze Strecke.
# Ohne Echtzeit-Prioritaet gibt es Aussetzer, und jede Luecke wuerde einen
# Mittelwert nach unten ziehen — genau daran ist die erste Messung
# gescheitert: sie schwankte zwischen 213 und 225 Hz bei identischem Signal.
kreuz = []
for i in range(1, len(a)):
    if a[i-1] < 0 <= a[i]:
        kreuz.append(i - 1 + (-a[i-1] / (a[i] - a[i-1])))
if len(kreuz) < 10:
    print("  zu wenige Nulldurchgaenge"); sys.exit(0)
perioden = sorted(kreuz[i+1] - kreuz[i] for i in range(len(kreuz)-1))
median = perioden[len(perioden)//2]
f = sr / median
aussetzer = sum(1 for p in perioden if p > median * 1.5)
print(f"  {len(kreuz)} Nulldurchgaenge, {aussetzer} auffaellig lange Perioden (Aussetzer)")
cent = 1200*math.log2(f/432.0)
print()
print(f"  Eingang    440.00 Hz")
print(f"  Ausgang    {f:.2f} Hz   (Median)")
print(f"  Abweichung {cent:+.2f} Cent zu 432")
print()
print("  Umgestimmt, ohne dass jemand verkabelt hat." if abs(f-432) < 4
      else "  Unveraendert — MyRetuner wurde umgangen.")
ENDE

kill -TERM $SPID 2>/dev/null || true
wait $SPID 2>/dev/null || true
echo
sed 's/^/  /' /tmp/s.log
