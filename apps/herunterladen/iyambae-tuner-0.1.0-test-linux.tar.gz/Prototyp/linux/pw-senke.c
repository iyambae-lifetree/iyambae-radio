/*
 MyRetuner als virtuelle Senke für PipeWire — die tragfähige Bauform.

 Der erste Versuch (`pw-retuner.c`) benutzte `pw_filter`. Das legt einen
 DSP-Knoten an, den jemand von Hand verkabeln muss. Der Signalweg ließ sich
 damit nachweisen — 440 Hz hinein, 432,33 Hz heraus —, aber WirePlumber hat
 den Knoten nie betrachtet: keine `media.class`, also für die selbsttätige
 Verkabelung unsichtbar.

 Hier steht deshalb, was `module-loopback` und `filter-chain` intern tun:
 **zwei `pw_stream` als Knotenpaar** mit gemeinsamer `node.link-group`.

   Eingangsstrom   media.class = Audio/Sink
                   → erscheint als Wiedergabegerät. Anwendungen können ihn
                     auswählen, WirePlumber kann ihn zur Standardsenke machen.

   Ausgangsstrom   gewöhnlicher Wiedergabestrom
                   → geht auf das echte Ausgabegerät.

 Beide Knoten teilen sich einen Verarbeitungszyklus, weil `node.link-group`
 gesetzt ist. Verarbeitet wird im Rückruf des Eingangsstroms; der
 Ausgangspuffer wird dort mit geholt. Ohne diese Kopplung käme ein weiteres
 Quantum Latenz dazu.

 Damit stehen beide Wege offen:
 - WirePlumber ab 0.5: `filter.smart` hängt das Paar selbsttätig ein
 - WirePlumber 0.4 (Zorin 18): die Senke wird beim Start zur Standardsenke
   gemacht und beim Beenden zurückgestellt

 Echtzeit-Disziplin wie auf dem Mac: keine Allokation, kein Lock, keine
 Ausgabe im Rückruf.
*/
#include <pipewire/pipewire.h>
#include <spa/param/audio/format-utils.h>
#include <spa/pod/builder.h>
#include <spa/utils/result.h>

#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

#include "RetunerDSP.h"

#define KANAELE   2
#define RATE      48000

struct zustand {
    struct pw_main_loop *loop;
    struct pw_stream    *ein;      /* Audio/Sink — hier spielen Anwendungen hinein */
    struct pw_stream    *aus;      /* geht auf das echte Geraet */

    RTEngine *engine;

    /*
     Das ausgehandelte Format — NICHT das angeforderte.

     Beim ersten Versuch habe ich interleavtes F32 angefordert und dann
     angenommen, es auch zu bekommen. PipeWire handelt aber aus: Wird planar
     (F32P) vereinbart, liegt in datas[0] nur der linke Kanal, und die
     Rechnung `size / (4 * Kanaele)` liefert die halbe Rahmenzahl. Hoerbar
     wurde das als Ausgang bei 225 statt 432 Hz — eine Halbierung, die wie
     ein DSP-Fehler aussah und keiner war.

     Deshalb: aus param_changed lesen, nicht raten.
    */
    uint32_t format;               /* SPA_AUDIO_FORMAT_F32 oder _F32P */
    uint32_t kanaele;
    int      planar;

    atomic_ullong bloecke;
    atomic_ullong rahmen;
    atomic_uint   spitze_promille;

    /* Diagnose: Puffergroessen des ersten Zyklus, im Rueckruf nur gesetzt. */
    atomic_uint erst_rahmen_ein;
    atomic_uint erst_platz_aus;
    atomic_uint erst_n;
    atomic_uint erst_datas_ein;
    atomic_uint erst_datas_aus;
};

/*
 Laeuft im Datenthread. Beide Stroeme haengen in derselben link-group und
 werden im selben Zyklus bedient — deshalb darf der Ausgangspuffer hier
 geholt werden.
*/
static void verarbeite(void *nutzdaten)
{
    struct zustand *z = nutzdaten;

    struct pw_buffer *bein = pw_stream_dequeue_buffer(z->ein);
    if (!bein) return;
    struct pw_buffer *baus = pw_stream_dequeue_buffer(z->aus);
    if (!baus) { pw_stream_queue_buffer(z->ein, bein); return; }

    /*
     Schrittweite und Rahmenzahl folgen dem ausgehandelten Format:

       planar (F32P)    je Kanal ein eigener Datenblock, Schrittweite 1
       interleaved (F32) ein Block, Kanal k beginnt bei [k], Schrittweite Kanaele

     `rt_engine_process_channel` bedient beides ohne Umkopieren — genau dafür
     hat es seine Stride-Parameter, der Header sagt es wörtlich.
    */
    const uint32_t kan    = z->kanaele ? z->kanaele : KANAELE;
    const uint32_t stride = z->planar ? 1 : kan;
    const uint32_t proBlock = z->planar ? 1 : kan;   /* Floats je Rahmen im Block */

    struct spa_data *dein0 = &bein->buffer->datas[0];
    struct spa_data *daus0 = &baus->buffer->datas[0];

    uint32_t rahmen_ein = dein0->chunk->size / (sizeof(float) * proBlock);
    uint32_t platz_aus  = daus0->maxsize     / (sizeof(float) * proBlock);
    uint32_t n = rahmen_ein < platz_aus ? rahmen_ein : platz_aus;

    if (atomic_load_explicit(&z->bloecke, memory_order_relaxed) == 0) {
        atomic_store_explicit(&z->erst_rahmen_ein, rahmen_ein, memory_order_relaxed);
        atomic_store_explicit(&z->erst_platz_aus,  platz_aus,  memory_order_relaxed);
        atomic_store_explicit(&z->erst_n,          n,          memory_order_relaxed);
        atomic_store_explicit(&z->erst_datas_ein,  bein->buffer->n_datas, memory_order_relaxed);
        atomic_store_explicit(&z->erst_datas_aus,  baus->buffer->n_datas, memory_order_relaxed);
    }

    float spitze = 0.0f;

    for (uint32_t k = 0; k < kan; k++) {
        struct spa_data *de = &bein->buffer->datas[z->planar ? k : 0];
        struct spa_data *da = &baus->buffer->datas[z->planar ? k : 0];
        float *in  = de->data;
        float *out = da->data;
        if (!out) continue;

        float *in_k  = in  ? (z->planar ? in  : in  + k) : NULL;
        float *out_k = z->planar ? out : out + k;

        if (!in_k || n == 0) {
            for (uint32_t i = 0; i < n; i++) out_k[(size_t)i * stride] = 0.0f;
            continue;
        }

        rt_engine_process_channel(z->engine, k, in_k, stride, out_k, stride, n);

        for (uint32_t i = 0; i < n; i++) {
            float v = out_k[(size_t)i * stride];
            float a = v < 0 ? -v : v;
            if (a > spitze) spitze = a;
        }
    }

    if (n > 0) {
        unsigned p = (unsigned)(spitze * 1000.0f);
        if (p > atomic_load_explicit(&z->spitze_promille, memory_order_relaxed))
            atomic_store_explicit(&z->spitze_promille, p, memory_order_relaxed);
        atomic_fetch_add_explicit(&z->bloecke, 1, memory_order_relaxed);
        atomic_fetch_add_explicit(&z->rahmen, n, memory_order_relaxed);
    }

    for (uint32_t b = 0; b < baus->buffer->n_datas; b++) {
        struct spa_data *da = &baus->buffer->datas[b];
        da->chunk->offset = 0;
        da->chunk->stride = sizeof(float) * proBlock;
        da->chunk->size   = n * sizeof(float) * proBlock;
    }

    pw_stream_queue_buffer(z->ein, bein);
    pw_stream_queue_buffer(z->aus, baus);
}

/*
 Das ausgehandelte Format entgegennehmen. Ohne diesen Rückruf weiß der
 Verarbeitungsteil nicht, ob er planare oder interleavte Puffer bekommt — und
 rät dann falsch.
*/
static void format_geaendert(void *nutzdaten, uint32_t id, const struct spa_pod *param)
{
    struct zustand *z = nutzdaten;
    if (!param || id != SPA_PARAM_Format) return;

    struct spa_audio_info info = { 0 };
    if (spa_format_parse(param, &info.media_type, &info.media_subtype) < 0) return;
    if (info.media_type != SPA_MEDIA_TYPE_audio ||
        info.media_subtype != SPA_MEDIA_SUBTYPE_raw) return;
    if (spa_format_audio_raw_parse(param, &info.info.raw) < 0) return;

    z->format  = info.info.raw.format;
    z->kanaele = info.info.raw.channels;
    z->planar  = (info.info.raw.format == SPA_AUDIO_FORMAT_F32P);

    printf("  Ausgehandelt: %s, %u Kanaele, %u Hz\n",
           z->planar ? "F32P (planar)" : "F32 (interleaved)",
           info.info.raw.channels, info.info.raw.rate);
    fflush(stdout);
}

static const struct pw_stream_events ein_ereignisse = {
    PW_VERSION_STREAM_EVENTS,
    .param_changed = format_geaendert,
    .process = verarbeite,
};

/* Der Ausgangsstrom wird im Rueckruf des Eingangs mitbedient. */
static const struct pw_stream_events aus_ereignisse = {
    PW_VERSION_STREAM_EVENTS,
};

static struct pw_main_loop *g_loop;
static void bei_signal(void *d, int s) { (void)d; (void)s; pw_main_loop_quit(g_loop); }

int main(int argc, char **argv)
{
    double   abtastrate   = RATE;
    uint32_t verzoegerung = 2048;
    double   faktor       = 432.0 / 440.0;
    int      schlau       = 0;
    const char *ziel      = NULL;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--faktor") && i + 1 < argc)      faktor = atof(argv[++i]);
        else if (!strcmp(argv[i], "--frames") && i + 1 < argc) verzoegerung = (uint32_t)atoi(argv[++i]);
        else if (!strcmp(argv[i], "--schlau"))                 schlau = 1;
        else if (!strcmp(argv[i], "--ziel") && i + 1 < argc)   ziel = argv[++i];
    }

    struct zustand z = { 0 };
    z.engine = rt_engine_create(abtastrate, verzoegerung);
    if (!z.engine) { fprintf(stderr, "Engine konnte nicht angelegt werden\n"); return 1; }
    rt_engine_set_factor(z.engine, faktor);

    printf("  Engine: %.0f Hz, %u Frames, Faktor %.9f, Latenz %.2f ms\n",
           abtastrate, verzoegerung, rt_engine_get_factor(z.engine),
           rt_engine_latency_seconds(z.engine) * 1000.0);

    pw_init(&argc, &argv);
    z.loop = pw_main_loop_new(NULL);
    g_loop = z.loop;
    pw_loop_add_signal(pw_main_loop_get_loop(z.loop), SIGINT,  bei_signal, NULL);
    pw_loop_add_signal(pw_main_loop_get_loop(z.loop), SIGTERM, bei_signal, NULL);

    /* ---- Eingang: erscheint als Wiedergabegeraet ---------------------- */
    struct pw_properties *pein = pw_properties_new(
        PW_KEY_MEDIA_TYPE,       "Audio",
        PW_KEY_MEDIA_CATEGORY,   "Duplex",
        PW_KEY_MEDIA_CLASS,      "Audio/Sink",
        PW_KEY_MEDIA_ROLE,       "DSP",
        PW_KEY_NODE_NAME,        "myretuner",
        PW_KEY_NODE_DESCRIPTION, "MyRetuner",
        "node.link-group",       "myretuner",
        "node.virtual",          "true",
        "audio.channels",        "2",
        "audio.position",        "FL,FR",
        NULL);

    /* ---- Ausgang: gewoehnlicher Wiedergabestrom ----------------------- */
    struct pw_properties *paus = pw_properties_new(
        PW_KEY_MEDIA_TYPE,       "Audio",
        PW_KEY_MEDIA_CATEGORY,   "Playback",
        PW_KEY_MEDIA_ROLE,       "DSP",
        PW_KEY_NODE_NAME,        "myretuner-ausgang",
        PW_KEY_NODE_DESCRIPTION, "MyRetuner Ausgang",
        "node.link-group",       "myretuner",
        "node.passive",          "true",
        "audio.channels",        "2",
        "audio.position",        "FL,FR",
        NULL);

    if (schlau) {
        /* Ab WirePlumber 0.5: haengt das Paar selbsttaetig ein. */
        pw_properties_set(pein, "filter.smart", "true");
        pw_properties_set(pein, "filter.smart.name", "myretuner");
        if (ziel) pw_properties_set(pein, "filter.smart.target", ziel);
    }
    if (ziel && !schlau) pw_properties_set(paus, PW_KEY_TARGET_OBJECT, ziel);

    z.ein = pw_stream_new_simple(pw_main_loop_get_loop(z.loop),
                                 "myretuner", pein, &ein_ereignisse, &z);
    z.aus = pw_stream_new_simple(pw_main_loop_get_loop(z.loop),
                                 "myretuner-ausgang", paus, &aus_ereignisse, &z);
    if (!z.ein || !z.aus) { fprintf(stderr, "Stroeme nicht anlegbar\n"); return 1; }

    uint8_t puffer[1024];
    struct spa_pod_builder b = SPA_POD_BUILDER_INIT(puffer, sizeof(puffer));
    struct spa_audio_info_raw info = {
        .format   = SPA_AUDIO_FORMAT_F32,          /* interleaved */
        .rate     = (uint32_t)abtastrate,
        .channels = KANAELE,
        .position = { SPA_AUDIO_CHANNEL_FL, SPA_AUDIO_CHANNEL_FR },
    };
    const struct spa_pod *params[1];
    params[0] = spa_format_audio_raw_build(&b, SPA_PARAM_EnumFormat, &info);

    enum pw_stream_flags flags = PW_STREAM_FLAG_AUTOCONNECT
                               | PW_STREAM_FLAG_MAP_BUFFERS
                               | PW_STREAM_FLAG_RT_PROCESS;

    int r1 = pw_stream_connect(z.aus, PW_DIRECTION_OUTPUT, PW_ID_ANY, flags, params, 1);
    struct spa_pod_builder b2 = SPA_POD_BUILDER_INIT(puffer, sizeof(puffer));
    params[0] = spa_format_audio_raw_build(&b2, SPA_PARAM_EnumFormat, &info);
    int r2 = pw_stream_connect(z.ein, PW_DIRECTION_INPUT, PW_ID_ANY, flags, params, 1);

    if (r1 < 0 || r2 < 0) {
        fprintf(stderr, "Verbindung fehlgeschlagen: ein=%s aus=%s\n",
                spa_strerror(r2), spa_strerror(r1));
        return 1;
    }

    printf("  Virtuelle Senke \"MyRetuner\" angemeldet.\n");
    fflush(stdout);

    pw_main_loop_run(z.loop);

    printf("  Bloecke %llu, Rahmen %llu, Spitze %.3f\n",
           (unsigned long long)atomic_load(&z.bloecke),
           (unsigned long long)atomic_load(&z.rahmen),
           atomic_load(&z.spitze_promille) / 1000.0);
    printf("  Erster Zyklus: Eingang %u Rahmen (%u Bloecke), Ausgang Platz %u "
           "(%u Bloecke), verarbeitet %u\n",
           atomic_load(&z.erst_rahmen_ein), atomic_load(&z.erst_datas_ein),
           atomic_load(&z.erst_platz_aus),  atomic_load(&z.erst_datas_aus),
           atomic_load(&z.erst_n));

    pw_stream_destroy(z.ein);
    pw_stream_destroy(z.aus);
    pw_main_loop_destroy(z.loop);
    pw_deinit();
    rt_engine_destroy(z.engine);
    return 0;
}
