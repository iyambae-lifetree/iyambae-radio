#!/bin/bash
#
# Hängt WirePlumber den Filter von selbst ein?
#
# In `pruefe.sh` wird von Hand verkabelt. Das taugt zum Nachweis, nicht als
# Produkt: Niemand soll `pw-link` bemühen müssen, damit sein Ton umgestimmt
# wird. WirePlumber ab 0.5 kann das übernehmen — ein Filter mit
# `filter.smart = true` wird selbsttätig zwischen die Anwendungen und die
# Zielsenke geschoben, auch wenn das Gerät wechselt.
#
# Geprüft wird genau das: Ein Abspieler wird OHNE jede Verkabelung gestartet,
# und danach muss die Kette Abspieler → myretuner → Senke im Graphen stehen.
set -euo pipefail

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
export DEBIAN_FRONTEND=noninteractive

apt-get update -qq >/dev/null 2>&1
apt-get install -y -qq pipewire pipewire-pulse wireplumber libpipewire-0.3-dev \
    pkg-config gcc pulseaudio-utils dbus-x11 python3 >/dev/null 2>&1

echo "=== Fassungen ==="
echo "  PipeWire     $(pkg-config --modversion libpipewire-0.3)"
echo -n "  WirePlumber  "; wireplumber --version 2>&1 | head -1
if [ -f /usr/share/wireplumber/scripts/linking/get-filter-from-target.lua ]; then
    echo "  Smart-Filter-Skripte vorhanden — 0.5er Weg steht offen"
else
    echo "  KEINE Smart-Filter-Skripte — das ist der 0.4er Fall (Zorin 18)"
fi

echo
echo "=== Übersetzen ==="
gcc -O2 -std=c11 -pedantic -Wall -Wextra -c "$REPO/Sources/RetunerDSP/RetunerDSP.c" \
    -I"$REPO/Sources/RetunerDSP/include" -o /tmp/RetunerDSP.o
gcc -O2 -std=gnu11 -Wall -Wextra -c "$REPO/Prototyp/linux/pw-retuner.c" \
    -I"$REPO/Sources/RetunerDSP/include" $(pkg-config --cflags libpipewire-0.3) \
    -o /tmp/pw-retuner.o
gcc /tmp/pw-retuner.o /tmp/RetunerDSP.o -o /tmp/pw-retuner \
    $(pkg-config --libs libpipewire-0.3) -lm
echo "  OK"

echo
echo "=== Graph starten ==="
export XDG_RUNTIME_DIR=/run/user/0
mkdir -p "$XDG_RUNTIME_DIR"; chmod 700 "$XDG_RUNTIME_DIR"
dbus-daemon --session --fork --print-address > /tmp/dbus.addr 2>/dev/null
export DBUS_SESSION_BUS_ADDRESS="$(cat /tmp/dbus.addr)"
pipewire       > /tmp/pw.log  2>&1 &
sleep 2
wireplumber    > /tmp/wp.log  2>&1 &
pipewire-pulse > /tmp/pwp.log 2>&1 &
sleep 3

pactl load-module module-null-sink sink_name=lautsprecher >/dev/null
pactl set-default-sink   lautsprecher            2>/dev/null || true
pactl set-default-source lautsprecher.monitor    2>/dev/null || true
echo "  Standardsenke: $(pactl get-default-sink)"

echo
echo "=== Filter starten, MIT --schlau, OHNE jede Verkabelung ==="
/tmp/pw-retuner --schlau --ziel lautsprecher --faktor 0.98181818181818181818 \
    > /tmp/filter.log 2>&1 &
FPID=$!
sleep 4
sed 's/^/  /' /tmp/filter.log

echo
echo "=== Testton, ebenfalls ohne Verkabelung ==="
python3 - <<'ENDE'
import math, struct, wave
sr, hz, sek = 48000, 440.0, 5.0
with wave.open('/tmp/ton.wav','wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
    w.writeframes(b''.join(struct.pack('<h', int(0.6*32767*math.sin(2*math.pi*hz*n/sr)))
                           for n in range(int(sr*sek))))
ENDE

pw-record --channels 1 --rate 48000 /tmp/aufnahme.wav 2>/dev/null &
RPID=$!
sleep 1
# Kein --target: Der Abspieler geht auf die Standardsenke. Wenn der schlaue
# Filter greift, laeuft er trotzdem durch myretuner.
pw-play /tmp/ton.wav 2>/dev/null &
PPID_=$!
sleep 3

echo "=== Wie sieht der Graph jetzt aus? ==="
pw-link -l 2>/dev/null | sed 's/^/  /' | head -30

wait $PPID_ 2>/dev/null || true
sleep 1
kill -INT $RPID 2>/dev/null || true
wait $RPID 2>/dev/null || true

echo
echo "=== Messen ==="
python3 - <<'ENDE'
import wave, struct, math, sys
try: w = wave.open('/tmp/aufnahme.wav','rb')
except Exception as e: print("  nicht lesbar:", e); sys.exit(0)
sr, n, br = w.getframerate(), w.getnframes(), w.getsampwidth()
if n == 0: print("  leer"); sys.exit(0)
kan = w.getnchannels()
fmt = {1:'b',2:'h',4:'i'}[br]; skala = float(1 << (br*8-1))
werte = [v/skala for v in struct.unpack(f'<{n*kan}{fmt}', w.readframes(n))][::kan]
spitze = max(abs(v) for v in werte)
print(f"  {n} Rahmen, Spitze {spitze:.4f}")
if spitze < 0.001: print("  Stille."); sys.exit(0)
a = werte[len(werte)//3 : 2*len(werte)//3]
erste=letzte=None; z=0
for i in range(1,len(a)):
    if a[i-1] < 0 <= a[i]:
        t = i-1 + (-a[i-1]/(a[i]-a[i-1]))
        if erste is None: erste=t
        else: letzte=t; z+=1
if not z or letzte is None: print("  keine Nulldurchgaenge"); sys.exit(0)
f = z*sr/(letzte-erste)
print(f"  Eingang 440.00 Hz  →  Ausgang {f:.2f} Hz  ({1200*math.log2(f/432.0):+.2f} Cent zu 432)")
print()
print("  432 Hz  = WirePlumber hat den Filter selbst eingehaengt." if abs(f-432) < 3
      else "  440 Hz  = der Filter wurde UMGANGEN, der schlaue Weg greift nicht.")
ENDE

kill -TERM $FPID 2>/dev/null || true
wait $FPID 2>/dev/null || true
echo
sed 's/^/  /' /tmp/filter.log
