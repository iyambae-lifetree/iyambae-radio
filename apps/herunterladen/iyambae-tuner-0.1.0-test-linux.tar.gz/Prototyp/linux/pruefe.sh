#!/bin/bash
#
# Prüfstand für den PipeWire-Filterknoten — läuft ohne Hardware.
#
# Aufbau im Graphen:
#
#   Tonerzeuger  →  quelle (null-sink)
#                       │ monitor
#                       ▼
#                  myretuner:eingang
#                  myretuner:ausgang
#                       │
#                       ▼
#                   senke (null-sink)
#                       │ monitor
#                       ▼
#                   Aufnahme  →  WAV  →  Frequenzmessung
#
# Erwartung: 440 Hz hinein, 432 Hz heraus.
#
# Aufruf im Container:
#   docker run --rm -v <repo>:/src:ro debian:trixie-slim \
#       bash -lc "cp -r /src /w && bash /w/Prototyp/linux/pruefe.sh"
set -euo pipefail

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
export DEBIAN_FRONTEND=noninteractive

echo "=== Abhängigkeiten ==="
apt-get update -qq >/dev/null 2>&1
apt-get install -y -qq pipewire pipewire-pulse wireplumber libpipewire-0.3-dev \
    pkg-config gcc pulseaudio-utils dbus-x11 python3 >/dev/null 2>&1
echo "  PipeWire $(pkg-config --modversion libpipewire-0.3)"

echo
echo "=== Übersetzen ==="
#
# Getrennt, und das mit Absicht:
#
# `RetunerDSP.c` bleibt **streng ISO-C11**. Das ist die Zusage aus PORTING.md,
# und sie soll bei jedem Bau nachgeprüft werden, nicht nur behauptet.
#
# `pw-retuner.c` bindet PipeWire-Header ein, und die brauchen POSIX- bzw.
# GNU-Erweiterungen: `locale_t`, `newlocale`, `ssize_t`. Unter `-std=c11`
# blendet glibc die aus, und die Übersetzung bricht mitten in
# `spa/utils/string.h` ab. Deshalb dort `-std=gnu11`.
#
# Die Grenze verläuft also zwischen Kern und Hülle — genau da, wo sie hingehört.
gcc -O2 -std=c11 -pedantic -Wall -Wextra -c \
    "$REPO/Sources/RetunerDSP/RetunerDSP.c" \
    -I"$REPO/Sources/RetunerDSP/include" -o /tmp/RetunerDSP.o
echo "  Kern:   -std=c11 -pedantic, keine Warnungen"

gcc -O2 -std=gnu11 -Wall -Wextra -c \
    "$REPO/Prototyp/linux/pw-retuner.c" \
    -I"$REPO/Sources/RetunerDSP/include" \
    $(pkg-config --cflags libpipewire-0.3) -o /tmp/pw-retuner.o
echo "  Hülle:  -std=gnu11 (PipeWire-Header brauchen POSIX)"

gcc /tmp/pw-retuner.o /tmp/RetunerDSP.o -o /tmp/pw-retuner \
    $(pkg-config --libs libpipewire-0.3) -lm
echo "  gebunden — RetunerDSP unverändert übernommen"

echo
echo "=== Graph starten ==="
export XDG_RUNTIME_DIR=/run/user/0
mkdir -p "$XDG_RUNTIME_DIR"; chmod 700 "$XDG_RUNTIME_DIR"
dbus-daemon --session --fork --print-address > /tmp/dbus.addr 2>/dev/null
export DBUS_SESSION_BUS_ADDRESS="$(cat /tmp/dbus.addr)"
pipewire      > /tmp/pw.log  2>&1 &
sleep 2
wireplumber   > /tmp/wp.log  2>&1 &
pipewire-pulse> /tmp/pwp.log 2>&1 &
sleep 3
pactl load-module module-null-sink sink_name=quelle >/dev/null
pactl load-module module-null-sink sink_name=senke  >/dev/null
echo "  zwei virtuelle Senken angelegt"

echo
echo "=== Testton erzeugen: 440 Hz, 4 s, 48 kHz mono ==="
python3 - <<'ENDE'
import math, struct, wave
sr, hz, sek = 48000, 440.0, 4.0
with wave.open('/tmp/ton.wav', 'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
    w.writeframes(b''.join(
        struct.pack('<h', int(0.6 * 32767 * math.sin(2*math.pi*hz*n/sr)))
        for n in range(int(sr*sek))))
print("  /tmp/ton.wav geschrieben")
ENDE

echo
echo "=== Filter starten ==="
/tmp/pw-retuner --faktor 0.98181818181818181818 > /tmp/filter.log 2>&1 &
FPID=$!
sleep 3
sed 's/^/  /' /tmp/filter.log

echo
echo "=== Verkabeln ==="
pw-link quelle:monitor_FL myretuner:input_FL 2>&1 | sed 's/^/  /' || echo "  (Eingang bereits verbunden?)"
pw-link myretuner:output_FL senke:playback_FL 2>&1 | sed 's/^/  /' || echo "  (Ausgang bereits verbunden?)"
echo "  --- bestehende Verbindungen ---"
pw-link -l 2>/dev/null | grep -A1 myretuner | head -8 | sed 's/^/    /'

echo
echo "=== Ton hindurchschicken und mitschneiden ==="
#
# `--target` ist hier nicht verlässlich: Löst der Name nicht auf, fällt
# pw-record still auf die Standardquelle zurück — und die ist der Monitor der
# Standardsenke, also womöglich das unbearbeitete Eingangssignal. Genau darauf
# bin ich beim ersten Lauf hereingefallen: gemessen wurden exakt 440,00 Hz bei
# exakt der Eingangsamplitude.
#
# Deshalb: Standardsenke ausdrücklich setzen, und hinterher nachsehen, woran
# der Aufnehmer wirklich hängt.
# Beide getrennt setzen. Die Standardquelle folgt der Standardsenke NICHT —
# genau daran ist der erste Lauf gescheitert.
pactl set-default-sink   senke        2>/dev/null || true
pactl set-default-source senke.monitor 2>/dev/null || true
echo "  Standardsenke:  $(pactl get-default-sink 2>/dev/null)"
echo "  Standardquelle: $(pactl get-default-source 2>/dev/null)"

pw-record --channels 1 --rate 48000 /tmp/aufnahme.wav 2>/dev/null &
RPID=$!
sleep 2
echo "  --- woran haengt der Aufnehmer? ---"
pw-link -l 2>/dev/null | grep -B2 -A2 -i "pw-record\|capture" | head -10 | sed 's/^/    /'

pw-play --target quelle /tmp/ton.wav 2>/dev/null || true
sleep 1
kill -INT $RPID 2>/dev/null || true
wait $RPID 2>/dev/null || true
ls -l /tmp/aufnahme.wav 2>/dev/null | sed 's/^/  /' || echo "  keine Aufnahme entstanden"

echo
echo "=== Messen ==="
python3 - <<'ENDE'
import wave, struct, math, sys
try:
    w = wave.open('/tmp/aufnahme.wav', 'rb')
except Exception as e:
    print("  Aufnahme nicht lesbar:", e); sys.exit(0)

sr = w.getframerate(); n = w.getnframes(); breite = w.getsampwidth()
roh = w.readframes(n)
print(f"  {n} Rahmen, {sr} Hz, {breite*8} Bit, {w.getnchannels()} Kanal/Kanaele")
if n == 0:
    print("  Aufnahme ist leer — es floss kein Audio."); sys.exit(0)

fmt = {1:'b', 2:'h', 4:'i'}[breite]
skala = float(1 << (breite*8 - 1))
werte = [v/skala for v in struct.unpack(f'<{n*w.getnchannels()}{fmt}', roh)][::w.getnchannels()]

spitze = max(abs(v) for v in werte)
print(f"  Spitzenwert: {spitze:.4f}")
if spitze < 0.001:
    print("  Nur Stille aufgenommen."); sys.exit(0)

# Mittleres Drittel nehmen: Ein- und Ausschwingen ausklammern.
a = werte[len(werte)//3 : 2*len(werte)//3]
erste = letzte = None; zaehler = 0
for i in range(1, len(a)):
    if a[i-1] < 0 <= a[i]:
        t = i - 1 + (-a[i-1] / (a[i] - a[i-1]))
        if erste is None: erste = t
        else: letzte = t; zaehler += 1

if not zaehler or letzte is None:
    print("  Keine Nulldurchgaenge gefunden."); sys.exit(0)

f = zaehler * sr / (letzte - erste)
soll = 440.0 * 432.0 / 440.0
cent = 1200 * math.log2(f / soll) if f > 0 else 0
print()
print(f"  Eingang:   440.00 Hz")
print(f"  Ausgang:   {f:.2f} Hz")
print(f"  Erwartet:  {soll:.2f} Hz")
print(f"  Abweichung: {cent:+.2f} Cent")
ENDE

echo
echo "=== Filter beenden ==="
kill -TERM $FPID 2>/dev/null || true
wait $FPID 2>/dev/null || true
sed 's/^/  /' /tmp/filter.log
